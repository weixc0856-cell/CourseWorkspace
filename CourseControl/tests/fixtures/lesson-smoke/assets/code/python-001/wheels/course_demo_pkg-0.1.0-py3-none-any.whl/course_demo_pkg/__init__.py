__version__ = "0.1.0"


def greet():
    return "hello from local wheel"
